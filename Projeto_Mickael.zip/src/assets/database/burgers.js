export const burgerArray = [
  {
    id: 1,
    image: "src/assets/images/burgers/burguer2.jpeg",
    name: "Chedar Volcano",
    price: "7.50€",
  },
  {
    id: 2,
    image: "src/assets/images/burgers/chicken_burger.jpeg",
    name: "Chicken Burger",
    price: "6.50€",
  },
  {
    id: 3,
    image: "src/assets/images/burgers/texas_burger.jpeg",
    name: "Texas Burger",
    price: "8.50€",
  },
  {
    id: 4,
    image: "src/assets/images/burgers/egg_burger.jpeg",
    name: "Egg Burger",
    price: "7.50€",
  },
  {
    id: 5,
    image: "src/assets/images/burgers/cheeseburger.jpeg",
    name: "Double Cheese Burger",
    price: "8.50€",
  },
];
