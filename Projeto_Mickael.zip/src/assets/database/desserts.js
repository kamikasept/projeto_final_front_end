export const dessertArray = [
  {
    id: 1,
    image: "src/assets/images/desserts/brownie.jpeg",
    name: "Brownie",
    price: "4.50€",
  },
  {
    id: 2,
    image: "src/assets/images/desserts/cheesecake.jpeg",
    name: "Brownie",
    price: "4.50€",
  },
  {
    id: 3,
    image: "src/assets/images/desserts/lava_cake.jpeg",
    name: "Fondant de Chocolate",
    price: "4.50€",
  },
  {
    id: 4,
    image: "src/assets/images/desserts/tiramisu.jpeg",
    name: "Tiramisu",
    price: "4.50€",
  },
  {
    id: 5,
    image: "src/assets/images/desserts/banana_split.jpeg",
    name: "Banana Split",
    price: "4.50€",
  },
];
