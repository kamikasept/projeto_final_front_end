export const drinksArray = [
  {
    id: 1,
    image: "src/assets/images/drinks/coca_cola.jpeg",
    name: "Coca Cola",
    price: "1.50€",
  },
  {
    id: 2,
    image: "src/assets/images/drinks/fanta.png",
    name: "Fanta",
    price: "1.50€",
  },
  {
    id: 3,
    image: "src/assets/images/drinks/iced_tea.png",
    name: "Iced Tea",
    price: "1.50€",
  },
  {
    id: 4,
    image: "src/assets/images/drinks/luso.png",
    name: "Agua",
    price: "1.00€",
  },
  {
    id: 5,
    image: "src/assets/images/drinks/guarana.png",
    name: "Coca Cola",
    price: "1.50€",
  },
];
