export const aSideDishArray = [
  {
    id: 1,
    image: "src/assets/images/acompanhamentos/batata_frita.jpeg",
    name: "Batata Frita",
    price: "2.50€",
  },
  {
    id: 2,
    image: "src/assets/images/acompanhamentos/onion_rings.jpeg",
    name: "Onion Rings",
    price: "3.50€",
  },
  {
    id: 3,
    image: "src/assets/images/acompanhamentos/batata_rustica.jpeg",
    name: "Batata Rustica",
    price: "7.50€",
  },
  {
    id: 4,
    image: "src/assets/images/acompanhamentos/chicken_wings.jpeg",
    name: "Chicken Wings",
    price: "4.00€",
  },
  {
    id: 5,
    image: "src/assets/images/acompanhamentos/salada_cesar.jpeg",
    name: "Salada Cesar",
    price: "3.50€",
  },
];
