import React from "react";
import grupoImage from "../assets/images/grupos/grupo.jpg";
import Combos from "../components/Combos";

const Grupos = () => {
  return (
    <div className="grupos">
      <img className="grupoIamge" src={grupoImage} alt="Grupo a Mesa" />
      <h1 className="titleGrupos">
        Reuna amigos e familiares e passa um momento fantastico na nossa
        companhia
      </h1>
      <Combos />
    </div>
  );
};

export default Grupos;
