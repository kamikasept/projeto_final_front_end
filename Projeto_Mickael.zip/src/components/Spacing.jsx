const Spacing = () => {
  return <div className="spacing"></div>;
};

export default Spacing;
