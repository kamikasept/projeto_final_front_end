import React from "react";

const Combos = ({ combo }) => {
  return (
    <div className="combos">
      <h2>ola</h2>
    </div>
  );
};

export default Combos;
