import React from "react";

const BannerGrupo = () => {
  return <div className="ba"></div>;
};

export default BannerGrupo;
